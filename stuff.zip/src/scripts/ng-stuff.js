const parser = require('rss-parser');
const howler = require('howler');


angular.module('main',['ngAnimate'])


.controller('recents-controller', function($rootScope,$scope){

  $scope.clicked = false;
  $scope.edit = false;

  $scope.add = function(){
    $scope.recents.push({title: 'Cool Games Inc', author: 'Polygon'});
  };

  $scope.remove = function(){
    $scope.recents.pop();
  };



  $scope.imageClicked = function(title, author, image, desciption){
    //$scope.changeFocus("podcast-view");
    $rootScope.$broadcast('podcast-clicked',{
      'title': title,
      'author': author,
      'imageUrl': image,
      'description': desciption
    });
  }



  $scope.recents = [
    {
      'title': 'Planet Money',
      'author': 'NPR',
      'imageUrl':'https://media.npr.org/assets/img/2015/12/18/planetmoney_sq-c7d1c6f957f3b7f701f8e1d5546695cebd523720.jpg?s=1400',
      'description': "The economy, explained, with stories and surprises. Imagine you could call up a friend and say, \"Meet me at the bar and tell me what's going on with the economy.\" Now imagine that's actually a fun evening. That's what we\'re going for at <em>Planet Money</em>. People seem to like it."
    }
  ];


  $scope.keyDown = function(e){
    var key = e.key;
    if(key == "Enter"){
      var text = angular.element(document.querySelector('#url-input'))[0].value;
      if(text.length > 0){
        //Try to get URL
        add(text);
      }else{
        $scope.clicked = false;
        $scope.edit = false;
      }
    }
  };

  $scope.addButtonClicked = function(){
    if(!$scope.clicked){
      $scope.clicked = true;
    }else{
      var text = angular.element(document.querySelector('#url-input'))[0].value;
      if(text.length > 0){
        //Try to get URL
        add(text);
      }else{
        $scope.clicked = false;
        $scope.edit = false;
      }
    }
  };

  //https://www.npr.org/rss/podcast.php?id=510289
  var debounce = false;
  function add(text){
    $scope.edit = false;
    $scope.clicked = false;
    angular.element(document.querySelector('#url-input'))[0].value = "";

    parser.parseURL($scope.inputUrl, function(err,parsed){
      if(debounce == false){
        debounce = true;

        imageUrl = parsed.feed.itunes.image;
        author = parsed.feed.itunes.author;
        title = parsed.feed.title;
        description = parsed.feed.description;
        console.log(imageUrl);

        $scope.recents.unshift({
          'title': title,
          'author': author,
          'imageUrl': imageUrl,
          'description': description
        });

        $scope.$apply();
      }

    });

    debounce = false;
  }

})


.controller('podcast-view', function($scope){
  //$scope.open = true;
  $scope.$on('podcast-clicked',function(event, arg){
    $scope.author = arg.author;
    $scope.title = arg.title;
    $scope.imageUrl = arg.imageUrl;
    $scope.description = arg.description;
    $scope.open = true;
  });
})





.directive('scroll',function($window){
  var xVel = 0;
  return function(scope,element,attrs){
    angular.element(document.querySelector('.side-scroll')).bind('mousewheel',function(e){

      if(e.deltaY > 0){
        element[0].scrollLeft += 50;
      }else {
        element[0].scrollLeft -= 50;
      }

    });
  };
});
