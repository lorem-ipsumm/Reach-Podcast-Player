//const parser = require("rss-parser");


/*
parser.parseURL('http://feeds.gimletmedia.com/crimetownshow', function(err,parsed){
  var audioLink = parsed.feed.entries[0].enclosure.url;
  console.log(audioLink);


  var sound = new Howl({
    src: [audioLink],
    html5: true
  });

  //sound.play();
});
*/
